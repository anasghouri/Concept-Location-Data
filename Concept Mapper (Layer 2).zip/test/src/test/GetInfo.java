package test;

public class GetInfo {

}
