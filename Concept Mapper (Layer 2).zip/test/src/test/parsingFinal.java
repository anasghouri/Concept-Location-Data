package test;
import java.awt.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashSet;
import java.util.Set;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
public class parsingFinal {
	private static String [] concepts=null;
	static String difficulty="hard";
	//use ASTParse to parse string
	public static void parse(String str,String fileName) {
		ASTParser parser = ASTParser.newParser(AST.JLS3);
		parser.setSource(str.toCharArray());
		parser.setKind(ASTParser.K_COMPILATION_UNIT);

		final CompilationUnit cu = (CompilationUnit) parser.createAST(null);

		cu.accept(new ASTVisitor() {
			public boolean visit(VariableDeclarationFragment node) {
				SimpleName name = node.getName();
				for(int i=0; i<concepts.length; i++) {
					if(difficulty=="hard") {
						if(name.getIdentifier().equals(concepts[i])==true) {
							PrintWriter writer;
							try {
								writer = new PrintWriter(new BufferedWriter(new FileWriter("output.csv", true)));
								writer.println(name.getIdentifier() + "," + fileName + "," + "variable,Line No. " + cu.getLineNumber(name.getStartPosition())); 
								writer.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
					else {
						if(name.getIdentifier().contains(concepts[i])) {
							PrintWriter writer;
							try {
								writer = new PrintWriter(new BufferedWriter(new FileWriter("output.csv", true)));
								writer.println(name.getIdentifier() + "," + fileName + "," + "variable,Line No. " + cu.getLineNumber(name.getStartPosition())); 
								writer.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}

				}
				return false; // do not continue 
			}

			public boolean visit(MethodDeclaration  node) {
				SimpleName name = node.getName();
				//this.names.add(name.getIdentifier());

				for(int i=0; i<concepts.length; i++) {
					if(difficulty=="hard") {
						if(name.getIdentifier().equals(concepts[i])==true) {
							PrintWriter writer;
							try {
								writer = new PrintWriter(new BufferedWriter(new FileWriter("output.csv", true)));
								writer.println(name.getIdentifier() + "," + fileName + "," + "method,Line No. " + cu.getLineNumber(name.getStartPosition())); 
								writer.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
					else {
						if(name.getIdentifier().contains(concepts[i])) {
							PrintWriter writer;
							try {
								writer = new PrintWriter(new BufferedWriter(new FileWriter("output.csv", true)));
								writer.println(name.getIdentifier() + "," + fileName + "," + "method,Line No. " + cu.getLineNumber(name.getStartPosition())); 
								writer.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
				}
				return true; // do not continue 
			}
		});

	}

	//read file content into a string
	public static String readFileToString(String filePath) throws IOException {
		StringBuilder fileData = new StringBuilder(1000);
		BufferedReader reader = new BufferedReader(new FileReader(filePath));

		char[] buf = new char[10];
		int numRead = 0;
		while ((numRead = reader.read(buf)) != -1) {
			//System.out.println(numRead);
			String readData = String.valueOf(buf, 0, numRead);
			fileData.append(readData);
			buf = new char[1024];
		}

		reader.close();

		return  fileData.toString();	
	}

	//loop directory to get file list
	public static void ParseFilesInDir() throws IOException{
		File dirs = new File(".");
		String dirPath= "C:\\Users\\rtqay\\eclipse-workspace\\test\\src\\test";
		//String dirPath = dirs.getCanonicalPath() + File.separator+"src"+File.separator;

		File root = new File(dirPath);
		//System.out.println(rootDir.listFiles());
		File[] files = root.listFiles ( );
		String filePath = null;

		for (File f : files ) {
			filePath = f.getAbsolutePath();
			if(f.isFile()){
				parse(readFileToString(filePath),f.getName());
			}
		}
	}

	public static void main(String[] args) throws IOException {
		String keywords="buf,vist,cu,visit";
		difficulty="hard";  //soft or hard (hard means compare exact keywords, soft means match some chars)
		concepts=keywords.split(",");
		ParseFilesInDir();
		System.out.println("done");
	}
}
